import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Search as SearchIcon, Sparkles, Loader2 } from "lucide-react";

interface Photo {
  id: string;
  image_url: string;
  ai_description: string | null;
  created_at: string;
}

const Search = () => {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!query.trim()) {
      toast.error("Please enter a search query");
      return;
    }

    setLoading(true);
    setSearched(true);

    try {
      const { data, error } = await supabase
        .from("photos")
        .select("*")
        .ilike("ai_description", `%${query}%`)
        .order("created_at", { ascending: false });

      if (error) throw error;

      setResults(data || []);
      
      if (data && data.length === 0) {
        toast.info("No photos found matching your search");
      } else {
        toast.success(`Found ${data?.length || 0} photo(s)`);
      }
    } catch (error) {
      console.error("Search error:", error);
      toast.error("Failed to search photos");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container max-w-4xl py-8 px-4">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold mb-2 flex items-center justify-center gap-2">
          <Sparkles className="w-8 h-8 text-primary" />
          AI Photo Search
        </h1>
        <p className="text-muted-foreground">
          Describe what you're looking for in natural language
        </p>
      </div>

      <Card className="p-6 mb-8 shadow-elevated">
        <form onSubmit={handleSearch} className="space-y-4">
          <div className="space-y-2">
            <Input
              type="text"
              placeholder="e.g., beach sunset, family gathering, birthday cake..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="text-lg"
              disabled={loading}
            />
            <p className="text-sm text-muted-foreground">
              Try: "people smiling", "outdoor activities", "food", "nature"
            </p>
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Searching...
              </>
            ) : (
              <>
                <SearchIcon className="w-5 h-5 mr-2" />
                Search Photos
              </>
            )}
          </Button>
        </form>
      </Card>

      {searched && (
        <div>
          <h2 className="text-xl font-semibold mb-4">
            {results.length > 0 ? `Found ${results.length} result(s)` : "No results"}
          </h2>

          {results.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {results.map((photo) => (
                <Card
                  key={photo.id}
                  className="overflow-hidden group cursor-pointer hover:shadow-elevated transition-all animate-scale-in"
                >
                  <div className="aspect-square relative">
                    <img
                      src={photo.image_url}
                      alt="Search result"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity p-2 overflow-y-auto">
                      <p className="text-white text-xs">
                        {photo.ai_description}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">
                Try a different search query or upload more photos
              </p>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};

export default Search;