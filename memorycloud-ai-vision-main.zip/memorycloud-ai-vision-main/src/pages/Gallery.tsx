import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Upload, Loader2, Image as ImageIcon } from "lucide-react";
import { Card } from "@/components/ui/card";

interface Photo {
  id: string;
  image_url: string;
  ai_description: string | null;
  created_at: string;
}

const Gallery = () => {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadPhotos();
  }, []);

  const loadPhotos = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("photos")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setPhotos(data || []);
    } catch (error) {
      console.error("Error loading photos:", error);
      toast.error("Failed to load photos");
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    const uploadedPhotos: string[] = [];

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Upload all files
      for (const file of Array.from(files)) {
        if (!file.type.startsWith("image/")) {
          toast.error(`${file.name} is not an image`);
          continue;
        }

        const fileExt = file.name.split(".").pop();
        const fileName = `${user.id}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from("photos")
          .upload(fileName, file);

        if (uploadError) {
          console.error("Upload error:", uploadError);
          continue;
        }

        const { data: { publicUrl } } = supabase.storage
          .from("photos")
          .getPublicUrl(fileName);

        uploadedPhotos.push(publicUrl);
      }

      // Analyze photos with AI
      for (const imageUrl of uploadedPhotos) {
        try {
          const { data: aiData, error: aiError } = await supabase.functions.invoke(
            "analyze-photo",
            { body: { imageUrl } }
          );

          if (aiError) {
            console.error("AI analysis error:", aiError);
            // Still save photo without description
            await supabase.from("photos").insert({
              user_id: user.id,
              image_url: imageUrl,
              ai_description: null,
            });
            continue;
          }

          // Save photo with AI description
          await supabase.from("photos").insert({
            user_id: user.id,
            image_url: imageUrl,
            ai_description: aiData.description,
          });
        } catch (error) {
          console.error("Error processing photo:", error);
        }
      }

      toast.success(`${uploadedPhotos.length} photo(s) uploaded and analyzed!`);
      loadPhotos();
    } catch (error) {
      console.error("Upload error:", error);
      toast.error("Failed to upload photos");
    } finally {
      setUploading(false);
      // Reset input
      e.target.value = "";
    }
  };

  return (
    <div className="container max-w-6xl py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Photo Gallery</h1>
        <p className="text-muted-foreground">Upload and AI will analyze your photos</p>
      </div>

      <div className="mb-8">
        <label htmlFor="photo-upload">
          <Button
            variant="default"
            size="lg"
            disabled={uploading}
            className="cursor-pointer"
            asChild
          >
            <span>
              {uploading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Analyzing Photos...
                </>
              ) : (
                <>
                  <Upload className="w-5 h-5 mr-2" />
                  Upload Photos
                </>
              )}
            </span>
          </Button>
        </label>
        <input
          id="photo-upload"
          type="file"
          accept="image/*"
          multiple
          onChange={handleFileUpload}
          className="hidden"
          disabled={uploading}
        />
        <p className="text-sm text-muted-foreground mt-2">
          Select multiple photos to upload and analyze
        </p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : photos.length === 0 ? (
        <Card className="p-12 text-center">
          <ImageIcon className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-xl font-semibold mb-2">No photos yet</h3>
          <p className="text-muted-foreground">
            Upload your first photo to get started with AI-powered search
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {photos.map((photo) => (
            <Card
              key={photo.id}
              className="overflow-hidden group cursor-pointer hover:shadow-elevated transition-all animate-fade-in"
            >
              <div className="aspect-square relative">
                <img
                  src={photo.image_url}
                  alt="Photo"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity p-2 overflow-y-auto">
                  <p className="text-white text-xs">
                    {photo.ai_description || "No description"}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default Gallery;